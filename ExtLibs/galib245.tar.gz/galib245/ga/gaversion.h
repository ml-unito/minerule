/* ----------------------------------------------------------------------------
  version.h
  mbwall 10oct98

   This is the header file to keep track of the versions and revisions of the
GA library.  You can use the ident command to extract the version of galib
that you are using.
---------------------------------------------------------------------------- */
#ifndef _ga_version_h_
#define _ga_version_h_

static const char *rcsid = "$Date: 2000/02/03 15:04:48 $ $Revision: 2.4.5 $";

#endif
