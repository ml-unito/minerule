// ExtensionInfo.java
// Copyright (c) 1998, Regents of the University of California
// $Header: /usr/local/devel/GiST/libgist/src/amdbgist/ExtensionInfo.java,v 1.2 2000/03/15 00:23:21 mashah Exp $

public class ExtensionInfo 
{

String name;
int id;

ExtensionInfo(String n, int i)
{
    name = n;
    id = i;
}

}
