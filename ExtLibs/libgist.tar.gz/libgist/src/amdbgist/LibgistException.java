// LibgistException.java
// Copyright (c) 1998, Regents of the University of California
// $Id: LibgistException.java,v 1.1 1999/06/21 00:33:06 marcel Exp $

import java.lang.*;

public class LibgistException extends Exception 
{

public
LibgistException()
{
    super();
}

public
LibgistException(String s)
{
    super(s);
}

}
