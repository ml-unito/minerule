// ResultProcessor.java
// Copyright (c) 1998, Regents of the University of California
// $Header: /usr/local/devel/GiST/libgist/src/amdbgist/ResultProcessor.java,v 1.2 2000/03/15 00:23:23 mashah Exp $

interface ResultProcessor
{
    public void processItem(String key, String data);
}
