static char* timestamp = "\
Wed Dec 15 15:18:05 PST 1999 ";
