// Vector.cc							-*- c++ -*-
// Copyright (c) 1998, Regents of the University of California
// $Id: amdb_defs.cc,v 1.2 1998/05/09 05:52:34 aoki Exp $


#ifdef __GNUG__
#pragma implementation "amdb_defs.h"
#endif

#include "amdb_defs.h"

// G++ needs a place for the automatically generated implementations of the 
// inline functions for class _Vector, hence this empty source file.

static int someUnusedDummyVariable = 5;
