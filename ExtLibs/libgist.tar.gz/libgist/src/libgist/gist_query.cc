// gist_query.cc
// Copyright (c) 1998, Regents of the University of California
// $Id: gist_query.cc,v 1.3 1998/06/18 00:54:28 aoki Exp $

#include "gist_query.h"

#ifdef GNUG
#pragma implementation "gist_query.h"
#endif

gist_query_t::gist_query_t() 
{
}

gist_query_t::~gist_query_t() 
{
}
