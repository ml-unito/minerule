// PredInfoPack.java
// Copyright (c) 1998, Regents of the University of California
// $Id: PredInfoPack.java,v 1.1 1999/06/21 00:34:26 marcel Exp $

public class PredInfoPack {

DisplayPredInfo[] preds;
int               size;

public PredInfoPack(DisplayPredInfo[] preds, int size) {

    this.preds = preds;
    this.size = size;

}

}
