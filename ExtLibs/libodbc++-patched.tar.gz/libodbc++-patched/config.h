/* config.h.  Generated from config.h.in by configure.  */
/* config.h.in.  Generated from configure.ac by autoheader.  */

/* Defined if threads enabled */
/* #undef ENABLE_THREADS */

/* Define to 1 if you have the <cstdio> header file. */
#define HAVE_CSTDIO 1

/* Define to 1 if you have the <cstdlib> header file. */
#define HAVE_CSTDLIB 1

/* Define to 1 if you have the <cstring> header file. */
#define HAVE_CSTRING 1

/* Define to 1 if you have the <ctime> header file. */
#define HAVE_CTIME 1

/* Define to 1 if you have the <dlfcn.h> header file. */
#define HAVE_DLFCN_H 1

/* Define to 1 if you have the <exception> header file. */
#define HAVE_EXCEPTION 1

/* Define to 1 if you have the <inttypes.h> header file. */
#define HAVE_INTTYPES_H 1

/* Define to 1 if you have the <iostream> header file. */
#define HAVE_IOSTREAM 1

/* Define to 1 if you have the <iostream.h> header file. */
#define HAVE_IOSTREAM_H 1

/* Defined if using iodbc */
/* #undef HAVE_ISQLEXT_H */

/* Defined if using iodbc */
/* #undef HAVE_ISQL_H */

/* Define to 1 if you have the <istream> header file. */
#define HAVE_ISTREAM 1

/* Defined if using iodbc */
/* #undef HAVE_LIBIODBC */

/* defined if using unixodbc */
#define HAVE_LIBODBC 

/* Define to 1 if you have the `localtime_r' function. */
/* #undef HAVE_LOCALTIME_R */

/* Define if we have long long */
#define HAVE_LONG_LONG 1

/* Define to 1 if you have the <memory.h> header file. */
#define HAVE_MEMORY_H 1

/* Define to 1 if you have the `pthread_create' function. */
/* #undef HAVE_PTHREAD_CREATE */

/* Defined if pthreads are available */
/* #undef HAVE_PTHREAD_H */

/* Define to 1 if you have the <readline/history.h> header file. */
/* #undef HAVE_READLINE_HISTORY_H */

/* Define to 1 if you have the <readline/readline.h> header file. */
/* #undef HAVE_READLINE_READLINE_H */

/* Define to 1 if you have the <set> header file. */
#define HAVE_SET 1

/* Define to 1 if you have the <set.h> header file. */
#define HAVE_SET_H 1

/* Define to 1 if you have the `snprintf' function. */
#define HAVE_SNPRINTF 1

/* Define to 1 if you have the <sqlext.h> header file. */
#define HAVE_SQLEXT_H 

/* Define to 1 if you have the <sqlucode.h> header file. */
#define HAVE_SQLUCODE_H 1

/* Define to 1 if you have the <sql.h> header file. */
#define HAVE_SQL_H 

/* Define to 1 if you have the <sstream> header file. */
#define HAVE_SSTREAM 1

/* Define to 1 if you have the <stdint.h> header file. */
#define HAVE_STDINT_H 1

/* Define to 1 if you have the <stdlib.h> header file. */
#define HAVE_STDLIB_H 1

/* Define to 1 if you have the <string> header file. */
#define HAVE_STRING 1

/* Define to 1 if you have the <strings.h> header file. */
#define HAVE_STRINGS_H 1

/* Define to 1 if you have the <string.h> header file. */
#define HAVE_STRING_H 1

/* Define to 1 if you have the <strstream> header file. */
#define HAVE_STRSTREAM 1

/* Define to 1 if you have the <strstream.h> header file. */
/* #undef HAVE_STRSTREAM_H */

/* Define to 1 if you have the `strtoll' function. */
#define HAVE_STRTOLL 1

/* Define to 1 if you have the `strtoq' function. */
#define HAVE_STRTOQ 1

/* Whether the struct _GUID datatype is usable */
/* #undef HAVE_STRUCT_GUID */

/* Define to 1 if you have the <sys/stat.h> header file. */
#define HAVE_SYS_STAT_H 1

/* Define to 1 if you have the <sys/types.h> header file. */
#define HAVE_SYS_TYPES_H 1

/* Define to 1 if you have the <unistd.h> header file. */
#define HAVE_UNISTD_H 1

/* Define to 1 if you have the <vector> header file. */
#define HAVE_VECTOR 1

/* Define to 1 if you have the <vector.h> header file. */
#define HAVE_VECTOR_H 1

/* ODBC version */
/* #undef ODBCVER */

/* Name of package */
#define PACKAGE "libodbc++"

/* Define to the address where bug reports for this package should be sent. */
#define PACKAGE_BUGREPORT "libodbcxx-devel@lists.sourceforge.net"

/* Define to the full name of this package. */
#define PACKAGE_NAME "libodbcxx"

/* Define to the full name and version of this package. */
#define PACKAGE_STRING "libodbcxx 0.2.5"

/* Define to the one symbol short name of this package. */
#define PACKAGE_TARNAME "libodbc++"

/* Define to the version of this package. */
#define PACKAGE_VERSION "0.2.5"

/* The size of `int', as computed by sizeof. */
#define SIZEOF_INT 4

/* The size of `long', as computed by sizeof. */
#define SIZEOF_LONG 8

/* The size of `long long', as computed by sizeof. */
#define SIZEOF_LONG_LONG 8

/* Define to 1 if you have the ANSI C header files. */
#define STDC_HEADERS 1

/* Version number of package */
#define VERSION "0.2.5"
